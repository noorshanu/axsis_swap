self.__NEXT_FONT_MANIFEST={
  "pages": {
    "/_app": [
      "static/media/4fe01c5260ceaef7-s.p.ttf",
      "static/media/41c61de72f90ed3e-s.p.otf",
      "static/media/b33587e5b2ea6d2b-s.p.otf"
    ]
  },
  "app": {},
  "appUsingSizeAdjust": false,
  "pagesUsingSizeAdjust": true
}