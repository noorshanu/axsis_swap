export default function page() {
    return (
     <>Live Stake</>
    )
  }
  