export default function page() {
    return (
     <>Create Stake</>
    )
  }
  